public interface UnboundedStack<T> extends Stack<T> {
    void push(T t);
}
