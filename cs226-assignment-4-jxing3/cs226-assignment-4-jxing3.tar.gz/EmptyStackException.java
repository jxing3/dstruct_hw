/**
    Exception thrown when stack is empty.
*/
public class EmptyStackException extends RuntimeException {
    /** Shuts up the Java compiler. */
    static final long serialVersionUID = 0L;
}
