/**
    Exception thrown when Queue is empty.
*/
public class EmptyQueueException extends RuntimeException {
    /** Shuts up the Java compiler. */
    static final long serialVersionUID = 0L;
}
