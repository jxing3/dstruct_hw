/* Jesse Xing
   jxing3@jhu.edu
*/
//see assignment page: Assignment 1 Prob 3 for details

//Defines ResetableCounter Interface as an extension of the Counter Interface
public interface ResetableCounter extends Counter{

  void reset();
}
