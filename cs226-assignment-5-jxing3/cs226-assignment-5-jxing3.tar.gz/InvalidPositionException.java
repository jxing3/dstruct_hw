/**
    Exception thrown by list for invalid positions.
*/
public class InvalidPositionException extends RuntimeException {
    /** Serialization stuff, please ignore. */
    static final long serialVersionUID = 0;
}
