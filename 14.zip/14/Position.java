public interface Position<T> {
}
