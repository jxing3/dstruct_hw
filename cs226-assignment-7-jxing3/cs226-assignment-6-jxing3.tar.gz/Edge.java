/**
    Edge position for graph.
    @param <T> Type of element on edge.
*/
public interface Edge<T> extends Position<T> {
}
