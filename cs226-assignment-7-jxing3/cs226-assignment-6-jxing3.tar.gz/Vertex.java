/**
    Vertex position for graph.
    @param <T> Type of element on vertex.
*/
public interface Vertex<T> extends Position<T> {
}
