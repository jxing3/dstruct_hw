/**Index exception class- Gives index exception when called
*/

public class IndexException extends Exception {
    static final long serialVersionUID = 0L;
}
