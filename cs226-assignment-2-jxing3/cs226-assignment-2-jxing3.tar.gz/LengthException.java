/**Length exception class- Gives Length Exception when called
*/

public class LengthException extends Exception {
    static final long serialVersionUID = 0L;
}
